# Wi-Fi Band Controller — starter project

A Kotlin + Jetpack Compose Android starter targeting Android 10–16 (minSdk 29).

## Open
1. Install Android Studio.
2. Choose **Open** and select this project folder.
3. Allow Gradle sync to complete.
4. Connect an Android device and press Run.

## Current implementation
- Reads the current Wi-Fi connection information when Android exposes it.
- Classifies 2.4 GHz and 5 GHz from the reported frequency.
- Provides a basic preferred-band UI.
- Includes a helper to construct an Android 12+ `WifiNetworkSpecifier` with `setBand()`.

## Important limitation
The UI switch is currently a preference only. It does not yet reconnect automatically.
`WifiNetworkSpecifier` requests an app-scoped network and requires a user-approved
`ConnectivityManager.requestNetwork()` flow. It does not permanently lock the device's
ordinary saved Wi-Fi connection. Android 10–11 do not expose the same band-specific
request API to ordinary third-party apps.

The next milestone is to implement and test the complete request/callback/release flow,
then decide whether it can help the app's own traffic without disrupting normal internet.
Do not describe this starter as a system-wide band locker.

## Permissions
The starter requests fine location and, on Android 13+, Nearby Wi-Fi Devices.
Android version, target SDK, location settings, and manufacturer privacy behavior can
change which Wi-Fi fields are available.
