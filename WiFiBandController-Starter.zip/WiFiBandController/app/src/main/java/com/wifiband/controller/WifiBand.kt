package com.wifiband.controller

enum class WifiBand(val label: String) {
    GHZ_2_4("2.4 GHz"),
    GHZ_5("5 GHz"),
    UNKNOWN("Unknown");

    companion object {
        fun fromFrequencyMhz(frequency: Int): WifiBand = when (frequency) {
            in 2400..2500 -> GHZ_2_4
            in 4900..5900 -> GHZ_5
            else -> UNKNOWN
        }
    }
}

data class WifiStatus(
    val ssid: String = "Unavailable",
    val frequencyMhz: Int? = null,
    val rssiDbm: Int? = null,
    val band: WifiBand = WifiBand.UNKNOWN,
    val detail: String = "Waiting for Wi-Fi permission"
)
