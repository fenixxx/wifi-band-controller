package com.wifiband.controller

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.os.Build
import androidx.core.content.ContextCompat

class WifiRepository(private val context: Context) {
    private val wifiManager =
        context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

    fun readCurrentConnection(): WifiStatus {
        val hasLocation = ContextCompat.checkSelfPermission(
            context, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        val hasNearby = Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(
                context, Manifest.permission.NEARBY_WIFI_DEVICES
            ) == PackageManager.PERMISSION_GRANTED

        if (!hasLocation && Build.VERSION.SDK_INT <= 32) {
            return WifiStatus(detail = "Grant location permission to read Wi-Fi details.")
        }
        if (Build.VERSION.SDK_INT >= 33 && !hasNearby && !hasLocation) {
            return WifiStatus(detail = "Grant Nearby devices permission to continue.")
        }

        return try {
            @Suppress("DEPRECATION")
            val info = wifiManager.connectionInfo
            val frequency = info?.frequency ?: 0
            val ssid = info?.ssid?.takeUnless {
                it == WifiManager.UNKNOWN_SSID || it.isNullOrBlank()
            } ?: "SSID hidden by Android"

            if (frequency <= 0) {
                WifiStatus(ssid = ssid, detail = "Connected band is not exposed by this device.")
            } else {
                val band = WifiBand.fromFrequencyMhz(frequency)
                WifiStatus(
                    ssid = ssid,
                    frequencyMhz = frequency,
                    rssiDbm = info.rssi,
                    band = band,
                    detail = "Live connection information (subject to Android privacy restrictions)."
                )
            }
        } catch (security: SecurityException) {
            WifiStatus(detail = "Android denied Wi-Fi information access: ${security.message}")
        } catch (error: Exception) {
            WifiStatus(detail = "Could not read Wi-Fi status: ${error.message}")
        }
    }
}
