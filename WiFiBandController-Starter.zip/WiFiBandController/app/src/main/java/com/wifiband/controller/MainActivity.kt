package com.wifiband.controller

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWifiPermissions()
        setContent { MaterialTheme { WifiBandHome() } }
    }

    private fun requestWifiPermissions() {
        val permissions = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) {
            permissions += Manifest.permission.NEARBY_WIFI_DEVICES
        }
        permissionLauncher.launch(permissions.toTypedArray())
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun WifiBandHome() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val repository = remember { WifiRepository(context) }
    var status by remember { mutableStateOf(repository.readCurrentConnection()) }
    var preferredBand by remember { mutableStateOf(WifiBand.GHZ_5) }
    var autoRetry by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        while (true) {
            status = repository.readCurrentConnection()
            delay(5_000)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Wi-Fi Band Controller") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            ElevatedCard {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("CURRENT CONNECTION", style = MaterialTheme.typography.labelMedium)
                    Text(status.band.label, style = MaterialTheme.typography.headlineLarge)
                    Text(status.ssid)
                    Text(status.frequencyMhz?.let { "$it MHz" } ?: "Frequency unavailable")
                    Text(status.rssiDbm?.let { "Signal: $it dBm" } ?: "Signal unavailable")
                    Text(status.detail, style = MaterialTheme.typography.bodySmall)
                }
            }

            Text("Preferred Wi-Fi band", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                FilterChip(
                    selected = preferredBand == WifiBand.GHZ_2_4,
                    onClick = { preferredBand = WifiBand.GHZ_2_4 },
                    label = { Text("2.4 GHz") }
                )
                FilterChip(
                    selected = preferredBand == WifiBand.GHZ_5,
                    onClick = { preferredBand = WifiBand.GHZ_5 },
                    label = { Text("5 GHz") }
                )
            }

            ElevatedCard {
                Row(
                    Modifier.fillMaxWidth().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Automatic recovery")
                        Text(
                            "Retry when the connection is not on your preferred band.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Switch(checked = autoRetry, onCheckedChange = { autoRetry = it })
                }
            }

            Button(
                onClick = { status = repository.readCurrentConnection() },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Refresh connection")
            }

            Text(
                "Important: Android does not let ordinary apps permanently force the phone's " +
                    "system Wi-Fi band. Automatic recovery is not active yet in this starter " +
                    "build. The next implementation step is the user-approved network request " +
                    "flow for Android 12+ and safe fallback guidance for Android 10–11.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
