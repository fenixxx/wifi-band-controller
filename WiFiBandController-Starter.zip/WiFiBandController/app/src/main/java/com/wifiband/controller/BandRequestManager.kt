package com.wifiband.controller

import android.content.Context
import android.net.wifi.WifiNetworkSpecifier
import android.os.Build
import android.util.Log

/**
 * Android 12+ supports requesting a network on a selected band.
 *
 * Important: this creates an app-scoped network request. It does NOT permanently
 * change the device's normal saved Wi-Fi connection or guarantee system-wide routing.
 * A real app must obtain user approval through ConnectivityManager.requestNetwork()
 * and handle the resulting NetworkCallback lifecycle.
 */
class BandRequestManager(private val context: Context) {
    fun isBandRequestApiAvailable(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

    fun buildSpecifier(ssid: String, band: WifiBand): WifiNetworkSpecifier? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return null
        if (ssid.isBlank() || band == WifiBand.UNKNOWN) return null

        return try {
            val builder = WifiNetworkSpecifier.Builder()
                .setSsid(ssid)

            when (band) {
                WifiBand.GHZ_2_4 -> builder.setBand(WifiNetworkSpecifier.BAND_24_GHZ)
                WifiBand.GHZ_5 -> builder.setBand(WifiNetworkSpecifier.BAND_5_GHZ)
                WifiBand.UNKNOWN -> return null
            }
            builder.build()
        } catch (error: Exception) {
            Log.e("BandRequestManager", "Unable to build band request", error)
            null
        }
    }
}
